import java.util.HashMap;
/**
 * Write a description of class Item here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
 
public class Item
{
    private String description;
    private int weight;
    
    /**
     * Create a new item with the given description and weight.
     */
    public Item(String description, int weight)
    {
        this.description = description;
        this.weight = weight;
    }

    public int getWeight() {
        return weight;
    }
    
    public String getDescription() {
        return description;
    }
}

