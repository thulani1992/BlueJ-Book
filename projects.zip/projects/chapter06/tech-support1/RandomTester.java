import java.util.Random;

/**
 * Write a description of class RandomTester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RandomTester
{
    private Random ram;
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class RandomTester
     */
    public RandomTester()
    {
        ram = new Random();
        
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void printOne(int upperLimit)
    {
        int index = ram.nextInt(upperLimit);
        System.out.println(index);
    }
    
 public void printMany(int howMany)
    {
        int i = 0;
        while(i < howMany) {
            
        int index = ram.nextInt();
        System.out.println(index);
        
        i++;
    }
}

public void throwDice()
    {
        int index = ram.nextInt(6);
        System.out.println(index);
    }
    
    public void getResponce()
    {
        int index = ram.nextInt(3);
        if(index == 1){
            p
    }
}
