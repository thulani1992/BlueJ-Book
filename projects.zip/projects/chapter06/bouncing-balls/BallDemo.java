import java.awt.Color;
import java.util.HashSet;
import java.util.Random;
/**
 * Class BallDemo - a short demonstration showing animation with the 
 * Canvas class. 
 *
 * @author Michael Kölling and David J. Barnes
 * @version 2016.02.29
 */

public class BallDemo   
{
    private Canvas myCanvas;
    private Random randGen;

    /**
     * Create a BallDemo object. Creates a fresh canvas and makes it visible.
     */
    public BallDemo()
    {
        myCanvas = new Canvas("Ball Demo", 600, 500);
        randGen = new Random();
    }

    /**
     * Simulate two bouncing balls
     */
    public void bounce(int howManyBalls)
    {
        int ground = 400;// position of the ground line
        
        myCanvas.setVisible(true);

        // draw the ground
        myCanvas.setForegroundColor(Color.BLACK);
        myCanvas.drawLine(50, ground, 550, ground);
        HashSet<BouncingBall> balls = new HashSet<BouncingBall>();
        for(int p=0; p<howManyBalls; p++) {
            int d = randGen.nextInt(200);

        // create and show the balls
        BouncingBall ball = new BouncingBall(50 + 50 * p, 50, d, Color.BLUE, ground, myCanvas);
        balls.add(ball);
        ball.draw();
    }
        

        // make them bounce
        boolean finished =  false;
        while (!finished) {
            myCanvas.wait(50);           // small delay
            for(BouncingBall ball : balls) {
                ball.move();
            // stop once ball has travelled a certain distance on x axis
            if(ball.getXPosition() >= 550 + 50*howManyBalls) {
                finished = true;
            }
        }
    }
    for (BouncingBall ball : balls) {
        ball.erase();
    }
}
}
